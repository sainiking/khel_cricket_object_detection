# Cricket Equipment Detection > 2025-08-06 6:13pm
https://universe.roboflow.com/khel/cricket-equipment-detection-b2g0m

Provided by a Roboflow user
License: Public Domain

